import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Product } from '../models/product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private products: Product[] = [
    {
      id: 1,
      name: 'Elegant Evening Dress',
      description: 'Beautiful silk evening dress perfect for special occasions',
      price: 299.99,
      category: 'Dresses',
      imageUrl: 'https://jazmin.pk/cdn/shop/files/1_46e1a281-3085-41ba-bf23-1785e9c6069a.jpg?v=1733121391',
      inStock: true,
      sizes: ['XS', 'S', 'M', 'L', 'XL'],
      colors: ['Black', 'Navy', 'Burgundy']
    },
    {
      id: 2,
      name: 'Designer Handbag',
      description: 'Luxury leather handbag with gold hardware',
      price: 199.99,
      category: 'Accessories',
      imageUrl: 'https://img.drz.lazcdn.com/static/pk/p/1948a4b7d7715055e6c17d042d070e80.png_720x720q80.png',
      inStock: true,
      colors: ['Black', 'Brown', 'Tan']
    },
    {
      id: 3,
      name: 'Cashmere Sweater',
      description: 'Soft cashmere sweater for ultimate comfort',
      price: 149.99,
      category: 'Tops',
      imageUrl: 'https://cdni.llbean.net/is/image/wim/505183_1155_41',
      inStock: true,
      sizes: ['XS', 'S', 'M', 'L', 'XL'],
      colors: ['Cream', 'Pink', 'Gray']
    }
  ];

  getProducts(): Observable<Product[]> {
    return of(this.products);
  }

  getProduct(id: number): Observable<Product | undefined> {
    const product = this.products.find(p => p.id === id);
    return of(product);
  }

  getProductsByCategory(category: string): Observable<Product[]> {
    const filteredProducts = this.products.filter(p => p.category === category);
    return of(filteredProducts);
  }
}