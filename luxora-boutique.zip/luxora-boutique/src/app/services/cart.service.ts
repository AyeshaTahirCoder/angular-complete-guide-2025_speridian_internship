import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CartItem } from '../models/cart-item.model';
import { Product } from '../models/product.model';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cartItems: CartItem[] = [];
  private cartSubject = new BehaviorSubject<CartItem[]>([]);
  
  cart$ = this.cartSubject.asObservable();

  addToCart(product: Product, quantity: number = 1, selectedSize?: string, selectedColor?: string): void {
    const existingItemIndex = this.cartItems.findIndex(item => 
      item.product.id === product.id && 
      item.selectedSize === selectedSize && 
      item.selectedColor === selectedColor
    );

    if (existingItemIndex > -1) {
      this.cartItems[existingItemIndex].quantity += quantity;
    } else {
      this.cartItems.push({
        product,
        quantity,
        selectedSize,
        selectedColor
      });
    }

    this.cartSubject.next([...this.cartItems]);
  }

  removeFromCart(index: number): void {
    this.cartItems.splice(index, 1);
    this.cartSubject.next([...this.cartItems]);
  }

  updateQuantity(index: number, quantity: number): void {
    if (quantity <= 0) {
      this.removeFromCart(index);
    } else {
      this.cartItems[index].quantity = quantity;
      this.cartSubject.next([...this.cartItems]);
    }
  }

  getTotal(): number {
    return this.cartItems.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  }

  getCartItemsCount(): number {
    return this.cartItems.reduce((count, item) => count + item.quantity, 0);
  }

  clearCart(): void {
    this.cartItems = [];
    this.cartSubject.next([]);
  }
}