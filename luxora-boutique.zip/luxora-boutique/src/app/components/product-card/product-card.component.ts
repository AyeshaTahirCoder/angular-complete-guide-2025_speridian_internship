import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Product } from '../../models/product.model';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-product-card',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="product-card">
      <div class="product-image">
        <img 
          [src]="product.imageUrl" 
          [alt]="product.name"
          (error)="onImageError($event)"
          [class.loading]="imageLoading"
          (load)="onImageLoad()" />
        
        <!-- Loading placeholder -->
        <div *ngIf="imageLoading" class="image-placeholder">
          <div class="spinner"></div>
        </div>
        
        <!-- Overlay on hover -->
        <div class="product-overlay">
          <button class="quick-view-btn" [routerLink]="['/product', product.id]">
            Quick View
          </button>
        </div>
        
        <!-- Stock badge -->
        <div class="stock-badge" [class.out-of-stock]="!product.inStock">
          {{ product.inStock ? 'In Stock' : 'Out of Stock' }}
        </div>
      </div>
      
      <div class="product-info">
        <h3 class="product-name">{{ product.name }}</h3>
        <p class="product-category">{{ product.category }}</p>
        <p class="product-price">\${{ product.price | number:'1.2-2' }}</p>
        
        <!-- Size options if available -->
        <div *ngIf="product.sizes && product.sizes.length > 0" class="size-options">
          <span class="size-label">Sizes:</span>
          <span *ngFor="let size of product.sizes.slice(0, 3)" class="size-tag">{{ size }}</span>
          <span *ngIf="product.sizes.length > 3" class="more-sizes">+{{ product.sizes.length - 3 }} more</span>
        </div>
        
        <button 
          class="add-to-cart-btn" 
          (click)="addToCart()"
          [disabled]="!product.inStock">
          {{ product.inStock ? 'Add to Cart' : 'Out of Stock' }}
        </button>
      </div>
    </div>
  `,
  styleUrls: ['./product-card.component.css']
})
export class ProductCardComponent {
  @Input() product!: Product;
  imageLoading = true;
  fallbackImage = 'https://via.placeholder.com/400x300/E5E5E5/666666?text=No+Image';

  constructor(private cartService: CartService) {}

  addToCart(): void {
    this.cartService.addToCart(this.product);
    // You could add a toast notification here
    console.log(`Added ${this.product.name} to cart`);
  }

  onImageLoad(): void {
    this.imageLoading = false;
  }

  onImageError(event: any): void {
    this.imageLoading = false;
    event.target.src = this.fallbackImage;
  }
}