import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { CartService } from '../../services/cart.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <header class="header">
      <div class="container">
        <div class="nav-brand">
          <a routerLink="/" class="logo">LUXORA</a>
        </div>
        
        <nav class="nav-menu">
          <ul class="nav-list">
            <li><a routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{exact: true}">Home</a></li>
            <li><a routerLink="/products" routerLinkActive="active">Products</a></li>
            <li><a routerLink="/checkout" routerLinkActive="active">Contact</a></li>
          </ul>
        </nav>
        
        <div class="nav-actions">
          <button class="cart-btn" routerLink="/cart">
            🛍️ Cart ({{ cartItemsCount$ | async }})
          </button>
        </div>
      </div>
    </header>
  `,
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  cartItemsCount$: Observable<number>;

  constructor(private cartService: CartService) {
    this.cartItemsCount$ = this.cartService.cart$.pipe(
      map(items => items.reduce((count, item) => count + item.quantity, 0))
    );
  }

  ngOnInit(): void {}
}