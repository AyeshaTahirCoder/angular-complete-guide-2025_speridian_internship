import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <footer class="footer">
      <div class="container">
        <div class="footer-content">
          <div class="footer-section">
            <h3>LUXORA</h3>
            <p>Discover the finest collection of luxury fashion. We believe in the power of elegance and style, offering carefully curated pieces from the world's most talented designers.</p>
          </div>
          
          <div class="footer-section">
            <h3>Quick Links</h3>
            <ul class="footer-links">
              <li><a routerLink="/">Home</a></li>
              <li><a routerLink="/products">Products</a></li>
              <li><a href="#about">About Us</a></li>
              <li><a routerLink="/contact">Contact</a></li>
            </ul>
          </div>
          
          <div class="footer-section">
            <h3>Categories</h3>
            <ul class="footer-links">
              <li><a href="#">Dresses</a></li>
              <li><a href="#">Tops</a></li>
              <li><a href="#">Accessories</a></li>
              <li><a href="#">New Arrivals</a></li>
            </ul>
          </div>
          
          <div class="footer-section">
            <h3>Contact Info</h3>
            <div class="contact-info">
              <p>📧 info@luxora.com</p>
              <p>📞 +1 (555) 123-4567</p>
              <p>📍 123 Fashion Street, Style City, SC 12345</p>
            </div>
            <div class="social-links">
              <a href="#" aria-label="Facebook">📘</a>
              <a href="#" aria-label="Instagram">📷</a>
              <a href="#" aria-label="Twitter">🐦</a>
              <a href="#" aria-label="Pinterest">📌</a>
            </div>
          </div>
        </div>
        
        <div class="footer-bottom">
          <p>&copy; 2024 Luxora. All rights reserved. | Privacy Policy | Terms of Service</p>
        </div>
      </div>
    </footer>
  `,
  styleUrls: ['./footer.component.css']
})
export class FooterComponent {
}