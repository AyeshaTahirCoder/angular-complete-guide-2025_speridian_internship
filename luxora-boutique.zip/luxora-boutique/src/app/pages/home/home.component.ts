import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ProductCardComponent } from '../../components/product-card/product-card.component';
import { ProductService } from '../../services/product.service';
import { Product } from '../../models/product.model';


@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule, ProductCardComponent],
  template: `
    <div class="home">
      <!-- Hero Section -->
      <section class="hero">
        <div class="hero-content">
          <h1 class="hero-title">Welcome to Luxora</h1>
          <p class="hero-subtitle">Discover the finest collection of luxury fashion</p>
          <button class="cta-button" routerLink="/products">Shop Now</button>
        </div>
      </section>

      <!-- Featured Products -->
      <section class="featured-products">
        <div class="container">
          <h2 class="section-title">Featured Products</h2>
          <div class="products-grid">
            <app-product-card 
              *ngFor="let product of featuredProducts" 
              [product]="product">
            </app-product-card>
          </div>
        </div>
      </section>

      <!-- About Section -->
      <section class="about">
        <div class="container">
          <div class="about-content">
            <h2>About Luxora</h2>
            <p>At Luxora, we believe in the power of elegance and style. Our carefully curated collection features the finest pieces from emerging and established designers, ensuring you always look your best.</p>
          </div>
        </div>
      </section>
    </div>
  `,
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  featuredProducts: Product[] = [];

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.productService.getProducts().subscribe(products => {
      this.featuredProducts = products.slice(0, 3); // Show first 3 products
    });
  }
}