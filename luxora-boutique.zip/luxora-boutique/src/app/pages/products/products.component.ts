import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductCardComponent } from '../../components/product-card/product-card.component';
import { Product } from '../../models/product.model';
import { ProductService } from '../../services/product.service';


@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule, ProductCardComponent],
  template: `
    <div class="products-page">
      <div class="container">
        <h1 class="page-title">Our Collection</h1>
        
        <div class="filters">
          <button 
            *ngFor="let category of categories" 
            class="filter-btn"
            [class.active]="selectedCategory === category"
            (click)="filterByCategory(category)">
            {{ category }}
          </button>
        </div>

        <div class="products-grid">
          <app-product-card 
            *ngFor="let product of filteredProducts" 
            [product]="product">
          </app-product-card>
        </div>
      </div>
    </div>
  `,
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products: Product[] = [];
  filteredProducts: Product[] = [];
  categories: string[] = ['All', 'Dresses', 'Tops', 'Accessories'];
  selectedCategory: string = 'All';

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.productService.getProducts().subscribe(products => {
      this.products = products;
      this.filteredProducts = products;
    });
  }

  filterByCategory(category: string): void {
    this.selectedCategory = category;
    if (category === 'All') {
      this.filteredProducts = this.products;
    } else {
      this.filteredProducts = this.products.filter(p => p.category === category);
    }
  }
}