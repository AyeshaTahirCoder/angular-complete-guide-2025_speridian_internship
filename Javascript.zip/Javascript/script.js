// Step 1: Pick elements from page (like grabbing toys)
const quoteElement = document.querySelector('.quote'); // The quote text
const personElement = document.querySelector('.person'); // The person name
const button = document.querySelector('#new-quote'); // The button

// Step 2: Load quotes from JSON file (like fetching data from server)
let quotes = []; // Empty array first

fetch('quotes.json') // Fetch the JSON file
    .then(response => response.json()) // Parse to JS object
    .then(data => {
        quotes = data; // Store the quotes
        console.log('Quotes loaded:', quotes); // Check in console
    })
    .catch(error => {
        console.error('Error loading quotes:', error); // If problem
        quoteElement.innerText = "Oops! Couldn't load quotes.";
    });

// Step 3: Add "ear" to button (event listener)
button.addEventListener('click', function() {
    if (quotes.length === 0) { // If not loaded yet
        quoteElement.innerText = "Quotes are loading... Try again!";
        return;
    }
    
    // Pick random quote
    const randomIndex = Math.floor(Math.random() * quotes.length);
    const randomQuote = quotes[randomIndex];
    
    // Change text on page
    quoteElement.innerText = `"${randomQuote.quote}"`; // Show quote
    personElement.innerText = `- ${randomQuote.person}`; // Show person
});